# 現場録音→文字起こし（最小ZIP・依存ゼロ）

## 目的
- Netlifyの「ドラッグ&ドロップ」でも動くよう、外部npm依存をゼロにした最小構成。

## Netlify デプロイ
1) ZIPを解凍
2) Netlifyで新規サイト作成 → フォルダをドラッグ&ドロップ
3) Site settings → Environment variables
   - OPENAI_API_KEY = sk-...
4) もう一度同じフォルダをドラッグ&ドロップ（環境変数反映のため）

## iPhone
- Safariで開く → 共有 → ホーム画面に追加

## 動作確認
- https://<your-site>/.netlify/functions/transcribe
  - GETだと Method Not Allowed が出れば Functions が生きています。
