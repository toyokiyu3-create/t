exports.handler = async function(event) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return { statusCode: 500, body: 'OPENAI_API_KEY is not set' };
  }

  let payload;
  try {
    payload = JSON.parse(event.body || '{}');
  } catch (e) {
    return { statusCode: 400, body: 'Invalid JSON' };
  }

  const audioBase64 = payload.audioBase64;
  const fileType = payload.fileType || 'audio/webm';
  const fileName = payload.fileName || 'audio.webm';
  const language = payload.language || 'ja';
  const hints = payload.hints || '';

  if (!audioBase64) {
    return { statusCode: 400, body: 'audioBase64 is required' };
  }

  // decode base64
  const buffer = Buffer.from(audioBase64, 'base64');

  try {
    const form = new FormData();
    form.append('model', 'whisper-1');
    form.append('language', language);
    if (hints) form.append('prompt', hints);

    const blob = new Blob([buffer], { type: fileType });
    form.append('file', blob, fileName);

    const resp = await fetch('https://api.openai.com/v1/audio/transcriptions', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${apiKey}` },
      body: form
    });

    const text = await resp.text();
    if (!resp.ok) {
      return { statusCode: resp.status, body: text };
    }

    // OpenAI returns JSON { text: "..." }
    return { statusCode: 200, headers: { 'content-type': 'application/json' }, body: text };
  } catch (e) {
    return { statusCode: 500, body: String(e && e.message ? e.message : e) };
  }
};
